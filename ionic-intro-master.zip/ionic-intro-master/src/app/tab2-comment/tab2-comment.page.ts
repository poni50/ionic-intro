import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-tab2-comment',
  templateUrl: './tab2-comment.page.html',
  styleUrls: ['./tab2-comment.page.scss'],
})
export class Tab2CommentPage implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
